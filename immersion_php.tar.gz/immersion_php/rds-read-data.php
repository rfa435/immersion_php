<h2>Address Book - AWSome Builder 3</h2><p style="background-image: url('https://ibb.co/74kKgLV');">
<?php 
  // This is a simple address book example for testing with RDS

  include('rds.conf.php');

  // Set address book variables
  if (isset($_REQUEST['mode'])) { 
    $mode = $_REQUEST['mode'];
  } else {
    $mode = "";
  }
  if (isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];
  } else {
    $id = "";
  }
  if (isset($_REQUEST['name'])) {
    $name = $_REQUEST['name'];
  } else {
    $name = "";
  }
  if (isset($_REQUEST['phone'])) {
    $phone = $_REQUEST['phone'];
  } else {
    $phone = "";
  }
  if (isset($_REQUEST['email'])) {
    $email = $_REQUEST['email'];
  } else {
    $email = "";
  }

  // Connect to the RDS database
  $serverName = $RDS_URL;
  $connectionOptions = array(
    "Database" => $RDS_DB,
    "Uid" => $RDS_user,
    "PWD" => $RDS_pwd,
    "MultipleActiveResultSets" => true,
    "Encrypt" => true,
    "TrustServerCertificate" => true,
    "ConnectionPooling" => true
  );

  $connect = sqlsrv_connect($serverName, $connectionOptions);

  // If table doesn't exist, create it
  $query = "IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'address') 
            CREATE TABLE address (
                id INT PRIMARY KEY IDENTITY(1,1),
                name VARCHAR(255),
                phone VARCHAR(20),
                email VARCHAR(255)
            )";
  $result = sqlsrv_query($connect, $query);

  if ($result === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  if ($mode == "add") {
    Print '<h2>Add Contact</h2>
           <p> 
           <form action=';
    echo $_SERVER['PHP_SELF']; 
    Print '
           method=post> <center>
           <table>
           <tr><td>Name:</td><td><input type="text" name="name" /></td></tr> 
           <tr><td>Phone:</td><td><input type="text" name="phone" /></td></tr> 
           <tr><td>Email:</td><td><input type="text" name="email" /></td></tr> 
           <tr><td colspan="2" align="center"><input type="submit" /></td></tr> 
           <input type=hidden name=mode value=added>
           </table> </center>
           </form> <p>';
  } 

  if ($mode == "added") {
    $query = "INSERT INTO address (name, phone, email) VALUES (?, ?, ?)";
    $params = array($name, $phone, $email);
    $stmt = sqlsrv_query($connect, $query, $params);

    if ($stmt === false) {
      die(print_r(sqlsrv_errors(), true));
    }
  }

  if ($mode == "edit") {
    Print '<h2>Edit Contact</h2> 
           <p> 
           <form action='; 
    echo $_SERVER['PHP_SELF']; 
    Print ' 
           method=post> 
           <table class="styled-table"> 
           <tr><td>Name:</td><td><input type="text" value="'; 
    Print $name; 
    print '" name="name" /></td></tr> 
           <tr><td>Phone:</td><td><input type="text" value="'; 
    Print $phone; 
    print '" name="phone" /></td></tr> 
           <tr><td>Email:</td><td><input type="text" value="'; 
    Print $email; 
    print '" name="email" /></td></tr> 
           <tr><td colspan="2" align="center"><input type="submit" /></td></tr> 
           <input type=hidden name=mode value=edited> 
           <input type=hidden name=id value='; 
    Print $id; 
    print '>
           </table> 
           </form> <p>'; 
  }

  if ($mode == "edited") {
    $query = "UPDATE address SET name = ?, phone = ?, email = ? WHERE id = ?";
    $params = array($name, $phone, $email, $id);
    $stmt = sqlsrv_query($connect, $query, $params);

    if ($stmt === false) {
      die(print_r(sqlsrv_errors(), true));
    }

    echo "Data Updated!<p>";
  }

  if ($mode == "remove") {
    $query = "DELETE FROM address WHERE id = ?";
    $params = array($id);
    $stmt = sqlsrv_query($connect, $query, $params);

    if ($stmt === false) {
      die(print_r(sqlsrv_errors(), true));
    }

    echo "Entry has been removed <p>";
  }

  $query = "SELECT * FROM address ORDER BY name ASC";
  $stmt = sqlsrv_query($connect, $query);

  if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  echo "<table border cellpadding=3>"; 
  echo "<tr><th width=100>Name</th> " .
    "<th width=100>Phone</th> " .
    "<th width=200>Email</th> " .
    "<th width=100 colspan=2>Admin</th></tr>";
  echo "<td colspan=5 align=right> " .
    "<a href=" . $_SERVER['PHP_SELF'] . "?mode=add>Add Contact</a></td>"; 

    while ($info = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
      echo "<tr><td>".$info['name'] . "</td> "; 
      echo "<td>".$info['phone'] . "</td> "; 
      echo "<td> <a href=mailto:".$info['email'] . ">" .$info['email'] . "</a></td>"; 
      echo "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&name=" . $info['name'] . "&phone=" . $info['phone'] ."&email=" . $info['email'] . "&mode=edit>Edit</a></td>";
      echo "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&mode=remove>Remove</a></td></tr>"; 
  }  

  echo "</table>"; 
?>

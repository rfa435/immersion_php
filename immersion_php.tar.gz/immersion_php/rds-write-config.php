<!DOCTYPE html>
<html>
<head>
    <title>AWS Tech Fundamentals Bootcamp</title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
    <meta http-equiv="refresh" content="10,URL=/rds.php" />
</head>

<body>
    <div id="wrapper">

        <?php include('menu.php'); ?>

        <?php 
        include 'rds.conf.php';

        $ep = $RDS_URL;
        $ep = str_replace(":3306", "", $ep);
        $db = $RDS_DB;
        $un = $RDS_user;
        $pw = $RDS_pwd;

        $mssql_command = "sqlcmd -S $ep -U $un -P $pw -d $db -i sql/addressbook.sql";

        $serverName = $ep;
        $connectionOptions = array(
            "Database" => $db,
            "Uid" => $un,
            "PWD" => $pw,
            "MultipleActiveResultSets" => true,
            "Encrypt" => true,
            "TrustServerCertificate" => true,
            "ConnectionPooling" => true
        );

        $connect = sqlsrv_connect($serverName, $connectionOptions);

        if(!$connect) {
            echo "<br /><p>Unable to Establish Connection:<i>" . print_r(sqlsrv_errors(), true) .  "</i></p>";
        } else {
            echo "<br /><p>Executing sql/addressbook.sql for database called ".$db;

            $query = file_get_contents("sql/addressbook.sql");
            $stmt = sqlsrv_query($connect, $query);

            if ($stmt === false) {
                die(print_r(sqlsrv_errors(), true));
            }

            sqlsrv_free_stmt($stmt);
            sqlsrv_close($connect);
        }

        echo "<br /><br /><p><i>Redirecting to rds.php in 10 seconds (or click <a href=rds.php>here</a>)</i></p>";
        ?>

    </div>
</body>
</html>
